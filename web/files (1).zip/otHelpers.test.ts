/**
 * src/lib/__tests__/otHelpers.test.ts
 *
 * Tests para otHelpers.ts: función otVencida.
 */

import { describe, expect, it } from 'vitest';
import { otVencida } from '@/lib/otHelpers';
import { makeOT, FECHAS } from '@/test/helpers';

describe('otVencida', () => {

  const HOY  = FECHAS.HOY;
  const AYER = FECHAS.AYER;
  const MAN  = FECHAS.MANANA;

  describe('estados finales — nunca vencidas aunque haya pasado la fecha', () => {
    const estadosFinales = ['completada', 'cancelada', 'rechazada'] as const;

    for (const estado of estadosFinales) {
      it(`OT en estado "${estado}" con fecha_estimada en el pasado → no vencida`, () => {
        const ot = makeOT({ estado, fecha_estimada: AYER });
        expect(otVencida(ot, HOY)).toBe(false);
      });
    }
  });

  describe('estados activos — vencida si fecha_estimada < hoy', () => {
    const estadosActivos = ['borrador', 'pendiente', 'aprobada', 'en_ejecucion'] as const;

    for (const estado of estadosActivos) {
      it(`OT en estado "${estado}" con fecha_estimada ayer → vencida`, () => {
        const ot = makeOT({ estado, fecha_estimada: AYER });
        expect(otVencida(ot, HOY)).toBe(true);
      });

      it(`OT en estado "${estado}" con fecha_estimada hoy → no vencida`, () => {
        const ot = makeOT({ estado, fecha_estimada: HOY });
        expect(otVencida(ot, HOY)).toBe(false);
      });

      it(`OT en estado "${estado}" con fecha_estimada mañana → no vencida`, () => {
        const ot = makeOT({ estado, fecha_estimada: MAN });
        expect(otVencida(ot, HOY)).toBe(false);
      });
    }
  });

  it('OT sin fecha_estimada (null) → no vencida', () => {
    const ot = makeOT({ estado: 'pendiente', fecha_estimada: null as unknown as string });
    expect(otVencida(ot, HOY)).toBe(false);
  });
});
