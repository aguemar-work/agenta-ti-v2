/**
 * src/api/__tests__/ordenTrabajo.api.test.ts
 *
 * Tests de integración para la capa API de ordenTrabajo.ts.
 * Valida: CRUD, transiciones de estado, campos obligatorios en completar.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { CrearOTInput } from '@/api/ordenTrabajo';
import { TEST_IDS, FECHAS, makeOT } from '@/test/helpers';

// ---------------------------------------------------------------------------
// Mock del cliente InsForge
// ---------------------------------------------------------------------------

const mockRpc      = vi.fn();
const mockFrom     = vi.fn();
const mockInsert   = vi.fn();
const mockSelect   = vi.fn();
const mockSingle   = vi.fn();
const mockUpdate   = vi.fn();
const mockEq       = vi.fn();

vi.mock('@/lib/insforge', () => ({
  getInsforge: () => ({
    database: {
      rpc:  mockRpc,
      from: mockFrom,
    },
  }),
}));

vi.mock('@/lib/schemas', async (importOriginal) => {
  const original = await importOriginal<typeof import('@/lib/schemas')>();
  return {
    ...original,
    parseOrdenTrabajo: (row: unknown) => row,
    parseTipoTrabajoOT: (row: unknown) => row,
  };
});

const mockOTData = makeOT();

function setupInsertChain(returnValue: unknown) {
  mockSingle.mockResolvedValue({ data: returnValue, error: null });
  mockSelect.mockReturnValue({ single: mockSingle });
  mockInsert.mockReturnValue({ select: mockSelect });
  mockFrom.mockReturnValue({ insert: mockInsert });
}

beforeEach(() => {
  vi.clearAllMocks();
  mockRpc.mockResolvedValue({ data: null, error: null });
});

// ---------------------------------------------------------------------------
// crearOrdenTrabajo
// ---------------------------------------------------------------------------

describe('crearOrdenTrabajo', () => {

  it('dado input válido con enviar=false, cuando se llama, entonces crea OT con estado borrador', async () => {
    setupInsertChain(mockOTData);

    const { crearOrdenTrabajo } = await import('@/api/ordenTrabajo');

    const input: CrearOTInput = {
      creado_por:     TEST_IDS.miembro,
      descripcion:    'Instalación de servidor en rack',
      area_destino:   'Infraestructura',
      modalidad:      'presencial',
      fecha_estimada: FECHAS.MANANA,
      enviar:         false,
    };

    const result = await crearOrdenTrabajo(input);

    expect(mockInsert).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({ estado: 'borrador' }),
      ]),
    );
    expect(result).toBeDefined();
  });

  it('dado input válido con enviar=true, cuando se llama, entonces crea OT con estado pendiente', async () => {
    setupInsertChain({ ...mockOTData, estado: 'pendiente' });

    const { crearOrdenTrabajo } = await import('@/api/ordenTrabajo');

    const input: CrearOTInput = {
      creado_por:     TEST_IDS.miembro,
      descripcion:    'Instalación de servidor en rack',
      area_destino:   'Infraestructura',
      modalidad:      'presencial',
      fecha_estimada: FECHAS.MANANA,
      enviar:         true,
    };

    await crearOrdenTrabajo(input);

    expect(mockInsert).toHaveBeenCalledWith(
      expect.arrayContaining([
        expect.objectContaining({ estado: 'pendiente' }),
      ]),
    );
  });

  it('dado error del servidor al insertar, cuando se llama, entonces relanza el error', async () => {
    mockSingle.mockResolvedValue({ data: null, error: new Error('constraint violation') });
    mockSelect.mockReturnValue({ single: mockSingle });
    mockInsert.mockReturnValue({ select: mockSelect });
    mockFrom.mockReturnValue({ insert: mockInsert });

    const { crearOrdenTrabajo } = await import('@/api/ordenTrabajo');

    await expect(
      crearOrdenTrabajo({
        creado_por:     TEST_IDS.miembro,
        descripcion:    'Prueba',
        area_destino:   'Sistemas',
        modalidad:      'presencial',
        fecha_estimada: FECHAS.MANANA,
        enviar:         false,
      }),
    ).rejects.toThrow('constraint violation');
  });
});

// ---------------------------------------------------------------------------
// aprobarOT (solo jefe)
// ---------------------------------------------------------------------------

describe('aprobarOT', () => {

  it('dado un jefe y OT en estado pendiente, cuando se aprueba, entonces el RPC sgtd_aprobar_ot se llama con los parámetros correctos', async () => {
    const { aprobarOT } = await import('@/api/ordenTrabajo');

    await expect(
      aprobarOT(TEST_IDS.ot1, TEST_IDS.jefe),
    ).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_aprobar_ot', {
      p_ot_id:      TEST_IDS.ot1,
      p_usuario_id: TEST_IDS.jefe,
    });
  });

  it('dado un error del servidor al aprobar, cuando se llama, entonces la función relanza el error', async () => {
    mockRpc.mockResolvedValue({ data: null, error: new Error('Solo el jefe puede aprobar') });

    const { aprobarOT } = await import('@/api/ordenTrabajo');

    await expect(
      aprobarOT(TEST_IDS.ot1, TEST_IDS.miembro),
    ).rejects.toThrow('Solo el jefe puede aprobar');
  });
});

// ---------------------------------------------------------------------------
// rechazarOT
// ---------------------------------------------------------------------------

describe('rechazarOT', () => {

  it('dado un jefe con motivo de rechazo, cuando se rechaza, entonces el RPC se llama con el motivo trimmed', async () => {
    const { rechazarOT } = await import('@/api/ordenTrabajo');

    await rechazarOT(TEST_IDS.ot1, TEST_IDS.jefe, '  Falta de presupuesto para el proyecto  ');

    expect(mockRpc).toHaveBeenCalledWith('sgtd_rechazar_ot', {
      p_ot_id:      TEST_IDS.ot1,
      p_usuario_id: TEST_IDS.jefe,
      p_motivo:     'Falta de presupuesto para el proyecto',
    });
  });
});

// ---------------------------------------------------------------------------
// completarOT — requiere receptor (nombre, DNI, cargo)
// ---------------------------------------------------------------------------

describe('completarOT', () => {

  it('dado todos los datos del receptor, cuando se completa, entonces el RPC recibe los campos de receptor trimmed', async () => {
    const { completarOT } = await import('@/api/ordenTrabajo');

    const input = {
      otId:                 TEST_IDS.ot1,
      usuarioId:            TEST_IDS.miembro,
      receptorNombre:       '  Juan Pérez  ',
      receptorDni:          '  12345678  ',
      receptorCargo:        '  Técnico de Sistemas  ',
      observacionesCierre:  'Trabajo completado sin incidencias',
    };

    await expect(completarOT(input)).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_completar_ot', {
      p_ot_id:                TEST_IDS.ot1,
      p_usuario_id:           TEST_IDS.miembro,
      p_receptor_nombre:      'Juan Pérez',
      p_receptor_dni:         '12345678',
      p_receptor_cargo:       'Técnico de Sistemas',
      p_observaciones_cierre: 'Trabajo completado sin incidencias',
    });
  });

  it('dado observaciones de cierre ausentes, cuando se completa, entonces p_observaciones_cierre es null', async () => {
    const { completarOT } = await import('@/api/ordenTrabajo');

    await completarOT({
      otId:           TEST_IDS.ot1,
      usuarioId:      TEST_IDS.miembro,
      receptorNombre: 'María López',
      receptorDni:    '87654321',
      receptorCargo:  'Gerente',
    });

    const call = mockRpc.mock.calls[0]?.[1] as Record<string, unknown>;
    expect(call?.p_observaciones_cierre).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// cancelarOrdenTrabajo
// ---------------------------------------------------------------------------

describe('cancelarOrdenTrabajo', () => {

  it('dado OT válida, cuando se cancela, entonces el RPC sgtd_cancelar_ot se llama', async () => {
    const { cancelarOrdenTrabajo } = await import('@/api/ordenTrabajo');

    await expect(
      cancelarOrdenTrabajo(TEST_IDS.ot1, TEST_IDS.miembro),
    ).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_cancelar_ot', {
      p_ot_id:      TEST_IDS.ot1,
      p_usuario_id: TEST_IDS.miembro,
    });
  });
});
