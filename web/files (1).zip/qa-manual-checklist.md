# QA Manual Checklist — Nexora (Agenda TI v3)

> **Propósito:** Registrar los escenarios que no pueden verificarse con tests automáticos
> por depender de entorno de producción, hardware externo, o interacción humana real.
>
> Ejecutar antes de cada release. Marcar cada ítem con ✅ PASS / ❌ FAIL / ⏭ N/A.

---

## 1. Autenticación y Auto-provisioning

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| A1 | Login con usuario nuevo del dominio `nufago.com` | 1. Ingresar email con dominio autorizado + contraseña válida 2. Hacer clic en "Iniciar sesión" | Usuario creado automáticamente con `rol = miembro`. Redirigido a pantalla principal. | |
| A2 | Login con dominio NO autorizado | Ingresar email de dominio externo (ej: gmail.com) | Sistema rechaza el acceso. Mensaje de error claro. | |
| A3 | Expiración de token de sesión | Mantener sesión activa >4 horas. Realizar alguna acción. | La app renueva el token automáticamente sin cerrar sesión. El usuario no ve ningún corte. | |
| A4 | Token inválido / sesión revocada | Invalidar token desde la BD (deactivar usuario). Realizar acción. | La app cierra sesión automáticamente y redirige a login. | |
| A5 | Flujo "Olvidé mi contraseña" | Ingresar email → recibir código → ingresar código → nueva contraseña | Flujo completo funciona. Email llega en <2 min. | |

---

## 2. Drag & Drop (Mi Semana y Tablero Kanban)

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| D1 | Arrastrar tarea a otro día de la semana | En Mi Semana, arrastrar tarjeta de Lunes a Miércoles | Tarea se mueve visualmente. `fecha_planificada` actualizada en BD. Estado cambia a `reprogramada` si corresponde. | |
| D2 | Arrastrar tarea atrasada a hoy | Tarea con `estado = atrasada`, arrastrar a hoy | Estado cambia a `reprogramada`, fecha actualizada a hoy. | |
| D3 | Arrastrar tarea entre columnas del Tablero | En Tablero Kanban, arrastrar de "Pendiente" a "En Progreso" | Estado actualizado visualmente y en BD. Toast de confirmación. | |
| D4 | Arrastrar tarea a columna "Bloqueada" sin justificación | Intentar arrastrar al Tablero hacia columna bloqueada | Modal de justificación aparece. Sin justificación válida (≥10 chars), la acción es rechazada. | |
| D5 | Arrastrar en móvil (touch) | Ejecutar D1 en dispositivo móvil o tablet | El comportamiento táctil funciona correctamente con `@dnd-kit`. | |

---

## 3. Notificaciones en tiempo real (Realtime InsForge)

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| R1 | Tarea asignada a Miembro actualizada por Jefe | Jefe edita tarea asignada al Miembro desde otra sesión | En la sesión del Miembro, la lista se actualiza automáticamente sin recargar. | |
| R2 | Nueva OT creada por Miembro visible para Jefe | Miembro crea OT. Jefe tiene la pantalla de OTs abierta. | OT aparece en la lista del Jefe en tiempo real. | |
| R3 | Desconexión y reconexión de red | Desactivar WiFi ~30s, luego reconectar | App maneja la desconexión sin crash. Al reconectar, los datos se sincronizan. | |

---

## 4. Flujos de Orden de Trabajo (OT) - Ciclo completo

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| O1 | Ciclo completo Borrador → Completada | 1. Miembro crea OT (enviar=false) 2. Miembro envía OT 3. Jefe aprueba 4. Miembro inicia ejecución 5. Miembro completa con receptor (nombre, DNI, cargo) | Cada transición refleja el nuevo estado. OT completada muestra datos del receptor. Número OT correlativo (OT-YYYY-NNN). | |
| O2 | Rechazo de OT por Jefe | 1. Miembro envía OT 2. Jefe rechaza con motivo | OT queda en estado `rechazada`. Motivo visible. Miembro no puede realizar más acciones. | |
| O3 | Impresión de OT | En una OT completada, hacer clic en "Imprimir" | Vista de impresión se abre con formato correcto. Datos del receptor incluidos. | |
| O4 | Miembro intenta aprobar OT | Miembro accede a OT pendiente e intenta aprobar (manipulando URL/API) | La operación es rechazada con error 403. BD protegida por RLS. | |

---

## 5. Bitácora — Conversión de Nota a Tarea/Evento

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| B1 | Convertir nota en Tarea planificada | 1. Crear nota en Bitácora 2. Hacer clic en "Convertir a Tarea" 3. Completar formulario de tarea | Nota marcada como `convertida_en = tarea`. Nueva tarea visible en Mi Semana con `nota_origen_id` vinculado. | |
| B2 | Convertir nota en Evento | 1. Crear nota 2. Convertir a Evento | Nota marcada como `convertida_en = evento`. Evento aparece en Mi Semana. | |
| B3 | Nota privada invisible para otros Miembros | Miembro A crea nota con `visibilidad = privado`. Miembro B abre Bitácora. | Miembro B no ve la nota de A. Jefe sí la ve. | |
| B4 | Nota `solo_jefe` invisible para Miembros | Crear nota con `visibilidad = solo_jefe`. | Solo el Jefe la ve. Los Miembros (incluyendo el autor) no la ven en lista general. | |

---

## 6. Recurrencia de Eventos

| # | Escenario | Pasos | Resultado esperado | Estado |
|---|-----------|-------|-------------------|--------|
| V1 | Crear evento recurrente semanal | Crear evento con `es_recurrente = true`, configurar recurrencia semanal | Evento se genera correctamente para las semanas configuradas. | |
| V2 | Verificar que `fecha_fin >= fecha_inicio` en UI | Intentar crear evento con fecha_fin anterior a fecha_inicio | Formulario muestra error de validación. No se envía al servidor. | |

---

## 7. Rendimiento y UX

| # | Escenario | Resultado esperado | Estado |
|---|-----------|-------------------|--------|
| P1 | Mi Semana con >20 tareas | La vista carga en <3s. Drag & Drop sin lag. | |
| P2 | Tablero con equipo de >10 miembros | Filtros por usuario/objetivo responden en <1s. | |
| P3 | Métricas con >3 meses de datos | Gráficas renderizan sin bloquear el hilo principal. | |

---

## 8. Accesibilidad básica

| # | Escenario | Resultado esperado | Estado |
|---|-----------|-------------------|--------|
| AC1 | Navegación por teclado en modales | Tab navega por todos los campos. Enter confirma. Escape cierra. | |
| AC2 | Contraste de colores en estados de tarea | Los badges de estado (atrasada, bloqueada, etc.) cumplen WCAG AA. | |

---

## Registro de ejecución

| Fecha | Ejecutado por | Release | Pass | Fail | N/A | Observaciones |
|-------|--------------|---------|------|------|-----|---------------|
|       |              |         |      |      |     |               |
