/**
 * src/lib/__tests__/tareaEstadoTransiciones.test.ts
 *
 * Tests de las reglas de transición de estado de Tarea.
 * Documenta qué transiciones son válidas y cuáles requieren justificación.
 *
 * Fuente de verdad: lib/constants.ts (MIN_JUSTIFICACION_CHARS) +
 * api/semana.ts (cambiarEstadoTarea).
 */

import { describe, expect, it } from 'vitest';
import type { EstadoTarea } from '@/types';
import { MIN_JUSTIFICACION_CHARS } from '@/lib/constants';

// ---------------------------------------------------------------------------
// Modelo de dominio: ¿qué estados requieren justificación?
// ---------------------------------------------------------------------------

const ESTADOS_CON_JUSTIFICACION: EstadoTarea[] = ['bloqueada', 'cancelada'];
const ESTADOS_SIN_JUSTIFICACION: EstadoTarea[] = ['pendiente', 'en_progreso', 'completada', 'reprogramada', 'atrasada'];

function requiereJustificacion(nuevoEstado: EstadoTarea): boolean {
  return ESTADOS_CON_JUSTIFICACION.includes(nuevoEstado);
}

function justificacionEsValida(justificacion: string | undefined): boolean {
  return (justificacion ?? '').trim().length >= MIN_JUSTIFICACION_CHARS;
}

describe('Reglas de justificación en cambio de estado de Tarea', () => {

  describe('estados que requieren justificación', () => {
    for (const estado of ESTADOS_CON_JUSTIFICACION) {
      it(`"${estado}" requiere justificación`, () => {
        expect(requiereJustificacion(estado)).toBe(true);
      });
    }
  });

  describe('estados que NO requieren justificación', () => {
    for (const estado of ESTADOS_SIN_JUSTIFICACION) {
      it(`"${estado}" no requiere justificación`, () => {
        expect(requiereJustificacion(estado)).toBe(false);
      });
    }
  });

  describe(`validación de longitud mínima (${MIN_JUSTIFICACION_CHARS} chars)`, () => {

    it('justificación vacía → inválida', () => {
      expect(justificacionEsValida('')).toBe(false);
    });

    it('justificación con solo espacios → inválida (trim aplicado)', () => {
      expect(justificacionEsValida('     ')).toBe(false);
    });

    it(`justificación con ${MIN_JUSTIFICACION_CHARS - 1} chars → inválida`, () => {
      expect(justificacionEsValida('x'.repeat(MIN_JUSTIFICACION_CHARS - 1))).toBe(false);
    });

    it(`justificación con exactamente ${MIN_JUSTIFICACION_CHARS} chars → válida`, () => {
      expect(justificacionEsValida('x'.repeat(MIN_JUSTIFICACION_CHARS))).toBe(true);
    });

    it('justificación con más de 10 chars → válida', () => {
      expect(justificacionEsValida('Justificación completamente válida y detallada')).toBe(true);
    });

    it('undefined se trata como cadena vacía → inválido', () => {
      expect(justificacionEsValida(undefined)).toBe(false);
    });
  });
});

// ---------------------------------------------------------------------------
// Reglas de estado derivado: atrasada
// ---------------------------------------------------------------------------

describe('Estado "atrasada" es calculado (no se puede fijar manualmente)', () => {

  it('atrasada es derivado — el trigger de BD lo calcula, no el cliente', () => {
    // Esta prueba documenta la regla de negocio:
    // No debe existir código que fije estado='atrasada' manualmente en el cliente.
    // El trigger de BD (migración 009/015) lo calcula al INSERT/UPDATE.
    expect(ESTADOS_SIN_JUSTIFICACION).toContain('atrasada');
    expect(ESTADOS_CON_JUSTIFICACION).not.toContain('atrasada');
  });
});
