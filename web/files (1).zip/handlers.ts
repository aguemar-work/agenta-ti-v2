/**
 * src/mocks/handlers.ts
 *
 * Handlers MSW v2 para interceptar llamadas al SDK InsForge (PostgREST + RPC).
 * Organizado por entidad. Importar en server.ts para tests unitarios/integración.
 *
 * Convención de URL InsForge:
 *   - Tablas:  POST/GET /rest/v1/<tabla>
 *   - RPCs:    POST     /rest/v1/rpc/<nombre_funcion>
 */

import { http, HttpResponse } from 'msw';

const BASE = 'http://test-insforge.local/rest/v1';

// ---------------------------------------------------------------------------
// Factories de respuesta
// ---------------------------------------------------------------------------

export const MOCK_IDS = {
  jefe:    'uuid-jefe-0000-0000-0000-000000000001',
  miembro: 'uuid-miembro-000-0000-0000-000000000002',
  tarea1:  'uuid-tarea-001-0000-0000-000000000003',
  tarea2:  'uuid-tarea-002-0000-0000-000000000004',
  evento1: 'uuid-evento-01-0000-0000-000000000005',
  obj1:    'uuid-obj-0001-0000-0000-000000000006',
  ot1:     'uuid-ot-00001-0000-0000-000000000007',
  nota1:   'uuid-nota-0001-0000-0000-000000000008',
};

export function mockTarea(overrides: Record<string, unknown> = {}) {
  return {
    id:                 MOCK_IDS.tarea1,
    titulo:             'Tarea de prueba',
    descripcion:        null,
    estado:             'pendiente',
    tipo:               'planificada',
    prioridad:          'media',
    fecha_planificada:  '2026-04-29',
    semana_planificada: '202618',
    fecha_completada:   null,
    asignado_a:         MOCK_IDS.miembro,
    objetivo_id:        null,
    creado_por:         MOCK_IDS.miembro,
    es_imprevisto:      false,
    nota_origen_id:     null,
    created_at:         '2026-01-01T00:00:00Z',
    updated_at:         '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

export function mockUsuario(overrides: Record<string, unknown> = {}) {
  return {
    id:         MOCK_IDS.miembro,
    nombre:     'Kevin Miembro',
    email:      'kevin@nufago.com',
    rol:        'miembro',
    activo:     true,
    created_at: '2026-01-01T00:00:00Z',
    updated_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

export function mockJefe(overrides: Record<string, unknown> = {}) {
  return mockUsuario({ id: MOCK_IDS.jefe, nombre: 'Ana Jefe', rol: 'jefe', email: 'ana@nufago.com', ...overrides });
}

export function mockObjetivo(overrides: Record<string, unknown> = {}) {
  return {
    id:             MOCK_IDS.obj1,
    titulo:         'Objetivo de prueba',
    descripcion:    null,
    fecha_limite:   null,
    estado:         'activo',
    creado_por:     MOCK_IDS.jefe,
    responsable_id: null,
    created_at:     '2026-01-01T00:00:00Z',
    updated_at:     '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

export function mockOT(overrides: Record<string, unknown> = {}) {
  return {
    id:                   MOCK_IDS.ot1,
    numero:               'OT-2026-001',
    creado_por:           MOCK_IDS.miembro,
    tipo_trabajo_id:      null,
    tarea_id:             null,
    objetivo_id:          null,
    estado:               'borrador',
    prioridad:            'normal',
    descripcion:          'Descripción de prueba',
    area_destino:         'Sistemas',
    ubicacion:            null,
    modalidad:            'presencial',
    fecha_estimada:       '2026-04-30',
    hora_inicio_est:      null,
    duracion_est_min:     null,
    equipos_materiales:   null,
    observaciones:        null,
    aprobado_por:         null,
    fecha_aprobacion:     null,
    motivo_rechazo:       null,
    fecha_inicio_real:    null,
    fecha_fin_real:       null,
    observaciones_cierre: null,
    receptor_nombre:      null,
    receptor_dni:         null,
    receptor_cargo:       null,
    created_at:           '2026-01-01T00:00:00Z',
    updated_at:           '2026-01-01T00:00:00Z',
    tipo_trabajo:         null,
    creador:              { nombre: 'Kevin Miembro', email: 'kevin@nufago.com' },
    aprobador:            null,
    tarea:                null,
    objetivo:             null,
    ...overrides,
  };
}

export function mockNota(overrides: Record<string, unknown> = {}) {
  return {
    id:            MOCK_IDS.nota1,
    contenido:     'Nota de prueba',
    usuario_id:    MOCK_IDS.miembro,
    objetivo_id:   null,
    visibilidad:   'todos',
    convertida_en: null,
    usuario:       { nombre: 'Kevin Miembro' },
    created_at:    '2026-01-01T00:00:00Z',
    updated_at:    '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Handlers: Tareas
// ---------------------------------------------------------------------------

export const tareaHandlers = [
  // GET tareas
  http.get(`${BASE}/tarea`, () =>
    HttpResponse.json([mockTarea()]),
  ),

  // INSERT tarea vía RPC crear_tarea_planificada
  http.post(`${BASE}/rpc/sgtd_crear_tarea_planificada`, () =>
    HttpResponse.json([mockTarea()]),
  ),

  // PATCH tarea (update)
  http.patch(`${BASE}/tarea`, () =>
    HttpResponse.json([mockTarea({ titulo: 'Tarea actualizada' })]),
  ),

  // RPC cambiar_estado_tarea
  http.post(`${BASE}/rpc/sgtd_cambiar_estado_tarea`, () =>
    HttpResponse.json(null),
  ),

  // RPC eliminar_tarea_con_motivo
  http.post(`${BASE}/rpc/sgtd_eliminar_tarea_con_motivo`, () =>
    HttpResponse.json(null),
  ),

  // RPC reprogramar
  http.post(`${BASE}/rpc/sgtd_reprogramar_tarea_con_log`, () =>
    HttpResponse.json(null),
  ),

  // RPC desbloquear
  http.post(`${BASE}/rpc/sgtd_desbloquear_tarea_con_log`, () =>
    HttpResponse.json(null),
  ),

  // RPC mover_tarea_dia
  http.post(`${BASE}/rpc/sgtd_mover_tarea_dia`, () =>
    HttpResponse.json(null),
  ),

  // RPC mover_tarea_columna (tablero)
  http.post(`${BASE}/rpc/sgtd_mover_tarea_columna`, () =>
    HttpResponse.json(null),
  ),

  // RPC snap_tarea_hoy
  http.post(`${BASE}/rpc/sgtd_snap_tarea_hoy`, () =>
    HttpResponse.json(null),
  ),
];

// ---------------------------------------------------------------------------
// Handlers: Eventos
// ---------------------------------------------------------------------------

export const eventoHandlers = [
  http.get(`${BASE}/evento`, () =>
    HttpResponse.json([]),
  ),

  http.post(`${BASE}/evento`, () =>
    HttpResponse.json({
      id:            MOCK_IDS.evento1,
      titulo:        'Reunión de prueba',
      tipo:          'reunion',
      fecha_inicio:  '2026-04-29T09:00:00.000Z',
      fecha_fin:     '2026-04-29T10:00:00.000Z',
      usuario_id:    MOCK_IDS.miembro,
      es_recurrente: false,
      created_at:    '2026-01-01T00:00:00Z',
      updated_at:    '2026-01-01T00:00:00Z',
    }),
  ),

  http.patch(`${BASE}/evento`, () =>
    HttpResponse.json({}),
  ),

  http.delete(`${BASE}/evento`, () =>
    new HttpResponse(null, { status: 204 }),
  ),
];

// ---------------------------------------------------------------------------
// Handlers: Objetivos
// ---------------------------------------------------------------------------

export const objetivoHandlers = [
  http.get(`${BASE}/objetivo`, () =>
    HttpResponse.json([mockObjetivo()]),
  ),

  http.post(`${BASE}/objetivo`, () =>
    HttpResponse.json(mockObjetivo()),
  ),

  http.patch(`${BASE}/objetivo`, () =>
    HttpResponse.json(mockObjetivo({ titulo: 'Objetivo actualizado' })),
  ),

  http.post(`${BASE}/rpc/sgtd_completar_objetivo`, () =>
    HttpResponse.json(null),
  ),

  http.post(`${BASE}/rpc/sgtd_eliminar_objetivo_con_motivo`, () =>
    HttpResponse.json(null),
  ),
];

// ---------------------------------------------------------------------------
// Handlers: Órdenes de Trabajo
// ---------------------------------------------------------------------------

export const ordenTrabajoHandlers = [
  http.get(`${BASE}/orden_trabajo`, () =>
    HttpResponse.json([mockOT()]),
  ),

  http.post(`${BASE}/orden_trabajo`, () =>
    HttpResponse.json(mockOT()),
  ),

  http.patch(`${BASE}/orden_trabajo`, () =>
    HttpResponse.json(mockOT({ estado: 'pendiente' })),
  ),

  http.get(`${BASE}/tipo_trabajo_ot`, () =>
    HttpResponse.json([{ id: 'uuid-tipo-1', nombre: 'MANTENIMIENTO', activo: true, created_at: '2026-01-01T00:00:00Z' }]),
  ),

  http.post(`${BASE}/rpc/sgtd_aprobar_ot`, () =>
    HttpResponse.json(null),
  ),

  http.post(`${BASE}/rpc/sgtd_rechazar_ot`, () =>
    HttpResponse.json(null),
  ),

  http.post(`${BASE}/rpc/sgtd_iniciar_ejecucion_ot`, () =>
    HttpResponse.json(null),
  ),

  http.post(`${BASE}/rpc/sgtd_completar_ot`, () =>
    HttpResponse.json(null),
  ),

  http.post(`${BASE}/rpc/sgtd_cancelar_ot`, () =>
    HttpResponse.json(null),
  ),
];

// ---------------------------------------------------------------------------
// Handlers: Usuario
// ---------------------------------------------------------------------------

export const usuarioHandlers = [
  http.get(`${BASE}/usuario`, () =>
    HttpResponse.json([mockUsuario(), mockJefe()]),
  ),

  http.post(`${BASE}/usuario`, () =>
    HttpResponse.json(mockUsuario()),
  ),

  http.patch(`${BASE}/usuario`, () =>
    HttpResponse.json(mockUsuario()),
  ),
];

// ---------------------------------------------------------------------------
// Export agrupado
// ---------------------------------------------------------------------------

export const handlers = [
  ...tareaHandlers,
  ...eventoHandlers,
  ...objetivoHandlers,
  ...ordenTrabajoHandlers,
  ...usuarioHandlers,
];
