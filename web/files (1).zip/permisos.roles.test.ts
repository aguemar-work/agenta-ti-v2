/**
 * src/components/__tests__/permisos.roles.test.ts
 *
 * Tests de permisos por rol para todas las combinaciones relevantes.
 * Cubre: puedeGestionarTarea (lib/permisos.ts), selectEsJefe (store/authStore),
 * y verificaciones de visibilidad de notas de bitácora por rol.
 *
 * Estos tests son unitarios puros (sin render de componentes).
 */

import { describe, expect, it } from 'vitest';
import { puedeGestionarTarea } from '@/lib/permisos';
import { selectEsJefe, selectRol } from '@/store/authStore';
import { makeTarea, makeUsuario, makeJefe, TEST_IDS } from '@/test/helpers';
import type { EstadoTarea } from '@/types';

// ---------------------------------------------------------------------------
// puedeGestionarTarea — cobertura exhaustiva de rol × propiedad × estado
// ---------------------------------------------------------------------------

describe('permisos por rol: puedeGestionarTarea', () => {

  // ── Jefe: puede gestionar cualquier tarea ─────────────────────────────────

  describe('Jefe', () => {
    const jefe = makeJefe();

    it('puede gestionar tarea propia', () => {
      expect(puedeGestionarTarea(makeTarea({ asignado_a: jefe.id }), jefe)).toBe(true);
    });

    it('puede gestionar tarea de otro miembro', () => {
      expect(puedeGestionarTarea(makeTarea({ asignado_a: TEST_IDS.miembro }), jefe)).toBe(true);
    });

    it('puede gestionar tarea de cualquier usuario del equipo', () => {
      const otroId = 'ffffffff-ffff-4fff-afff-ffffffffffff';
      expect(puedeGestionarTarea(makeTarea({ asignado_a: otroId }), jefe)).toBe(true);
    });

    const todosEstados: EstadoTarea[] = [
      'pendiente', 'en_progreso', 'reprogramada', 'completada',
      'bloqueada', 'atrasada', 'cancelada',
    ];
    for (const estado of todosEstados) {
      it(`puede gestionar tarea en estado "${estado}"`, () => {
        expect(puedeGestionarTarea(makeTarea({ estado, asignado_a: TEST_IDS.miembro }), jefe)).toBe(true);
      });
    }
  });

  // ── Miembro: solo puede gestionar sus propias tareas ──────────────────────

  describe('Miembro', () => {
    const miembro = makeUsuario({ id: TEST_IDS.miembro });

    it('puede gestionar tarea asignada a sí mismo', () => {
      expect(puedeGestionarTarea(makeTarea({ asignado_a: miembro.id }), miembro)).toBe(true);
    });

    it('NO puede gestionar tarea asignada al jefe', () => {
      expect(puedeGestionarTarea(makeTarea({ asignado_a: TEST_IDS.jefe }), miembro)).toBe(false);
    });

    it('NO puede gestionar tarea asignada a otro miembro', () => {
      const otroMiembro = 'eeeeeeee-eeee-4eee-aeee-eeeeeeeeeeee';
      expect(puedeGestionarTarea(makeTarea({ asignado_a: otroMiembro }), miembro)).toBe(false);
    });

    it('NO puede gestionar tarea con asignado_a null', () => {
      expect(
        puedeGestionarTarea(makeTarea({ asignado_a: null as unknown as string }), miembro),
      ).toBe(false);
    });
  });

  // ── Sin sesión ─────────────────────────────────────────────────────────────

  describe('Sin sesión (usuario null/undefined)', () => {
    it('devuelve false si usuario es null', () => {
      expect(puedeGestionarTarea(makeTarea(), null)).toBe(false);
    });

    it('devuelve false si usuario es undefined', () => {
      expect(puedeGestionarTarea(makeTarea(), undefined)).toBe(false);
    });
  });
});

// ---------------------------------------------------------------------------
// selectEsJefe / selectRol — lógica derivada del store
// ---------------------------------------------------------------------------

describe('selectEsJefe', () => {

  it('devuelve true para rol jefe', () => {
    const state = { usuario: makeJefe() } as Parameters<typeof selectEsJefe>[0];
    expect(selectEsJefe(state)).toBe(true);
  });

  it('devuelve false para rol miembro', () => {
    const state = { usuario: makeUsuario() } as Parameters<typeof selectEsJefe>[0];
    expect(selectEsJefe(state)).toBe(false);
  });

  it('devuelve false cuando usuario es null', () => {
    const state = { usuario: null } as Parameters<typeof selectEsJefe>[0];
    expect(selectEsJefe(state)).toBe(false);
  });
});

describe('selectRol', () => {

  it('devuelve "jefe" para usuario jefe', () => {
    const state = { usuario: makeJefe() } as Parameters<typeof selectRol>[0];
    expect(selectRol(state)).toBe('jefe');
  });

  it('devuelve "miembro" para usuario miembro', () => {
    const state = { usuario: makeUsuario() } as Parameters<typeof selectRol>[0];
    expect(selectRol(state)).toBe('miembro');
  });

  it('devuelve null cuando usuario es null', () => {
    const state = { usuario: null } as Parameters<typeof selectRol>[0];
    expect(selectRol(state)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Reglas de visibilidad de notas de bitácora por rol
// ---------------------------------------------------------------------------

describe('Visibilidad de notas de bitácora', () => {
  /**
   * Estas reglas son lógica de negocio pura — se validan aquí como referencia
   * de las políticas RLS que deben estar activas en BD.
   *
   * Regla: Jefe ve todo. Miembro solo ve sus propias notas y las de visibilidad "todos".
   */

  type VisibilidadNota = 'todos' | 'solo_jefe' | 'privado';

  function puedeVerNota(
    visibilidad: VisibilidadNota,
    notaUsuarioId: string,
    viendoUsuarioId: string,
    esJefe: boolean,
  ): boolean {
    if (esJefe) return true;
    if (notaUsuarioId === viendoUsuarioId) return true;
    return visibilidad === 'todos';
  }

  const JEFE_ID    = TEST_IDS.jefe;
  const MIEMBRO_ID = TEST_IDS.miembro;
  const OTRO_ID    = 'ffffffff-ffff-4fff-afff-000000000099';

  it('jefe puede ver nota privada de otro usuario', () => {
    expect(puedeVerNota('privado', MIEMBRO_ID, JEFE_ID, true)).toBe(true);
  });

  it('jefe puede ver nota solo_jefe', () => {
    expect(puedeVerNota('solo_jefe', MIEMBRO_ID, JEFE_ID, true)).toBe(true);
  });

  it('miembro puede ver su propia nota privada', () => {
    expect(puedeVerNota('privado', MIEMBRO_ID, MIEMBRO_ID, false)).toBe(true);
  });

  it('miembro puede ver nota de otro con visibilidad "todos"', () => {
    expect(puedeVerNota('todos', OTRO_ID, MIEMBRO_ID, false)).toBe(true);
  });

  it('miembro NO puede ver nota solo_jefe de otro usuario', () => {
    expect(puedeVerNota('solo_jefe', OTRO_ID, MIEMBRO_ID, false)).toBe(false);
  });

  it('miembro NO puede ver nota privada de otro usuario', () => {
    expect(puedeVerNota('privado', OTRO_ID, MIEMBRO_ID, false)).toBe(false);
  });
});
