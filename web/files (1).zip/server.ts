/**
 * src/mocks/server.ts
 *
 * Servidor MSW para entorno Node (Vitest).
 * Cada archivo de test llama beforeAll/afterAll/afterEach via este server.
 *
 * Uso:
 *   import { server } from '@/mocks/server';
 *   beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
 *   afterEach(() => server.resetHandlers());
 *   afterAll(() => server.close());
 */

import { setupServer } from 'msw/node';
import { handlers } from './handlers';

export const server = setupServer(...handlers);
