/**
 * src/api/__tests__/semana.api.test.ts
 *
 * Tests de integración para la capa API de semana.ts.
 * Usa MSW para interceptar llamadas al SDK InsForge en lugar de mockear módulos.
 *
 * Cubre: cambiarEstadoTarea, eliminarTareaConMotivo, reprogramarTareaConLog,
 *        desbloquearTareaConLog, crearTareaPlanificada.
 */

import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { http, HttpResponse } from 'msw';

import { server } from '@/mocks/server';
import { TEST_IDS, FECHAS } from '@/test/helpers';
import {
  cambiarEstadoTarea,
  eliminarTareaConMotivo,
  reprogramarTareaConLog,
  desbloquearTareaConLog,
} from '@/api/semana';
import { MIN_JUSTIFICACION_CHARS, MSG_JUSTIFICACION_CORTA } from '@/lib/constants';

// ---------------------------------------------------------------------------
// MSW setup
// ---------------------------------------------------------------------------

beforeAll(() => server.listen({ onUnhandledRequest: 'warn' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

// ---------------------------------------------------------------------------
// Mock del cliente InsForge — evita depender de env vars en tests
// ---------------------------------------------------------------------------

const mockRpc = vi.fn();
const mockDatabase = { rpc: mockRpc };

vi.mock('@/lib/insforge', () => ({
  getInsforge: () => ({ database: mockDatabase }),
}));

beforeEach(() => {
  mockRpc.mockClear();
  mockRpc.mockResolvedValue({ data: null, error: null });
});

// ---------------------------------------------------------------------------
// cambiarEstadoTarea
// ---------------------------------------------------------------------------

describe('cambiarEstadoTarea', () => {

  describe('estados que NO requieren justificación (en_progreso, completada)', () => {

    it('dado estado en_progreso, cuando se llama sin justificación, entonces llama al RPC sin error', async () => {
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'en_progreso' }),
      ).resolves.toBeUndefined();

      expect(mockRpc).toHaveBeenCalledWith('sgtd_cambiar_estado_tarea', expect.objectContaining({
        p_tarea_id:     TEST_IDS.tarea1,
        p_nuevo_estado: 'en_progreso',
      }));
    });

    it('dado estado completada, cuando se llama sin justificación, entonces llama al RPC sin error', async () => {
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'completada' }),
      ).resolves.toBeUndefined();
    });
  });

  describe('estados que SÍ requieren justificación (bloqueada, cancelada)', () => {

    it('dado estado bloqueada, cuando justificación es vacía, entonces lanza error de validación antes de llamar al API', async () => {
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'bloqueada', justificacion: '' }),
      ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);

      expect(mockRpc).not.toHaveBeenCalled();
    });

    it(`dado estado bloqueada, cuando justificación tiene ${MIN_JUSTIFICACION_CHARS - 1} caracteres, entonces lanza error`, async () => {
      const corta = 'x'.repeat(MIN_JUSTIFICACION_CHARS - 1);
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'bloqueada', justificacion: corta }),
      ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);
    });

    it(`dado estado bloqueada, cuando justificación tiene exactamente ${MIN_JUSTIFICACION_CHARS} caracteres, entonces el RPC se llama correctamente`, async () => {
      const exacta = 'x'.repeat(MIN_JUSTIFICACION_CHARS);
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'bloqueada', justificacion: exacta }),
      ).resolves.toBeUndefined();

      expect(mockRpc).toHaveBeenCalledWith('sgtd_cambiar_estado_tarea', expect.objectContaining({
        p_nuevo_estado:  'bloqueada',
        p_justificacion: exacta,
      }));
    });

    it('dado estado cancelada, cuando justificación es solo espacios, entonces lanza error (trim)', async () => {
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'cancelada', justificacion: '          ' }),
      ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);
    });

    it('dado estado cancelada, cuando justificación es válida, entonces el RPC se llama con justificación trimmed', async () => {
      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'cancelada', justificacion: '  Motivo de cancelación válido  ' }),
      ).resolves.toBeUndefined();

      const call = mockRpc.mock.calls[0]?.[1] as Record<string, unknown>;
      expect(call?.p_justificacion).toBe('Motivo de cancelación válido');
    });
  });

  describe('error de red', () => {

    it('dado un error del servidor (InsForge devuelve error), cuando se llama, entonces la función relanza el error', async () => {
      mockRpc.mockResolvedValue({ data: null, error: new Error('DB connection failed') });

      await expect(
        cambiarEstadoTarea({ tareaId: TEST_IDS.tarea1, nuevoEstado: 'en_progreso' }),
      ).rejects.toThrow('DB connection failed');
    });
  });
});

// ---------------------------------------------------------------------------
// eliminarTareaConMotivo
// ---------------------------------------------------------------------------

describe('eliminarTareaConMotivo', () => {

  it('dado un motivo válido (≥10 chars), cuando se llama, entonces el RPC se ejecuta correctamente', async () => {
    const motivo = 'Motivo de prueba suficientemente largo';
    await expect(
      eliminarTareaConMotivo({ tareaId: TEST_IDS.tarea1, usuarioId: TEST_IDS.miembro, motivo }),
    ).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_eliminar_tarea_con_motivo', expect.objectContaining({
      p_tarea_id:   TEST_IDS.tarea1,
      p_usuario_id: TEST_IDS.miembro,
      p_motivo:     motivo,
    }));
  });

  it('dado un motivo con 9 caracteres, cuando se llama, entonces lanza error antes de llegar al RPC', async () => {
    await expect(
      eliminarTareaConMotivo({ tareaId: TEST_IDS.tarea1, usuarioId: TEST_IDS.miembro, motivo: '123456789' }),
    ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);

    expect(mockRpc).not.toHaveBeenCalled();
  });

  it('dado un motivo vacío, cuando se llama, entonces lanza error de validación', async () => {
    await expect(
      eliminarTareaConMotivo({ tareaId: TEST_IDS.tarea1, usuarioId: TEST_IDS.miembro, motivo: '' }),
    ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);
  });
});

// ---------------------------------------------------------------------------
// reprogramarTareaConLog
// ---------------------------------------------------------------------------

describe('reprogramarTareaConLog', () => {

  it('dado una justificación válida y nueva fecha, cuando se llama, entonces el RPC se ejecuta con los parámetros correctos', async () => {
    const input = {
      tareaId:       TEST_IDS.tarea1,
      usuarioId:     TEST_IDS.miembro,
      nuevaFecha:    FECHAS.MANANA,
      justificacion: 'Reprogramado por reunión inesperada',
    };

    await expect(reprogramarTareaConLog(input)).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_reprogramar_tarea_con_log', expect.objectContaining({
      p_nueva_fecha:   FECHAS.MANANA,
      p_justificacion: input.justificacion,
    }));
  });

  it('dado una justificación corta, cuando se llama, entonces lanza error de validación', async () => {
    await expect(
      reprogramarTareaConLog({
        tareaId:       TEST_IDS.tarea1,
        usuarioId:     TEST_IDS.miembro,
        nuevaFecha:    FECHAS.MANANA,
        justificacion: 'Corta',
      }),
    ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);

    expect(mockRpc).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// desbloquearTareaConLog
// ---------------------------------------------------------------------------

describe('desbloquearTareaConLog', () => {

  it('dado una justificación válida, cuando se llama, entonces el RPC desbloquear se ejecuta', async () => {
    const input = {
      tareaId:       TEST_IDS.tarea1,
      usuarioId:     TEST_IDS.miembro,
      nuevaFecha:    FECHAS.MANANA,
      justificacion: 'El recurso bloqueante fue resuelto',
    };

    await expect(desbloquearTareaConLog(input)).resolves.toBeUndefined();

    expect(mockRpc).toHaveBeenCalledWith('sgtd_desbloquear_tarea_con_log', expect.objectContaining({
      p_tarea_id:      TEST_IDS.tarea1,
      p_justificacion: input.justificacion,
    }));
  });

  it('dado una justificación con espacios sólo, cuando se llama, entonces lanza error (trim aplicado)', async () => {
    await expect(
      desbloquearTareaConLog({
        tareaId:       TEST_IDS.tarea1,
        usuarioId:     TEST_IDS.miembro,
        nuevaFecha:    FECHAS.MANANA,
        justificacion: '         ',
      }),
    ).rejects.toThrow(MSG_JUSTIFICACION_CORTA);
  });
});
