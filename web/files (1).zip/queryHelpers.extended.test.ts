/**
 * src/lib/__tests__/queryHelpers.extended.test.ts
 *
 * Tests adicionales para invalidateRelatedQueries.
 * Complementan los tests existentes en queryHelpers.test.ts.
 */

import { describe, expect, it, vi } from 'vitest';
import { invalidateRelatedQueries } from '@/lib/queryHelpers';
import type { QueryClient } from '@tanstack/react-query';

function makeQueryClient(): QueryClient {
  return {
    invalidateQueries: vi.fn().mockResolvedValue(undefined),
  } as unknown as QueryClient;
}

describe('invalidateRelatedQueries', () => {

  it('invalida el grupo "semana" con la query key correcta', async () => {
    const qc = makeQueryClient();
    await invalidateRelatedQueries(qc, ['semana']);
    expect(qc.invalidateQueries).toHaveBeenCalledWith(
      expect.objectContaining({ queryKey: ['semana'] }),
    );
  });

  it('invalida múltiples grupos en paralelo', async () => {
    const qc = makeQueryClient();
    await invalidateRelatedQueries(qc, ['semana', 'tablero', 'objetivos']);
    expect(qc.invalidateQueries).toHaveBeenCalledTimes(3);
  });

  it('no llama invalidateQueries si la lista de grupos está vacía', async () => {
    const qc = makeQueryClient();
    await invalidateRelatedQueries(qc, []);
    expect(qc.invalidateQueries).not.toHaveBeenCalled();
  });

  it('invalida el grupo "ot" con la query key correcta', async () => {
    const qc = makeQueryClient();
    await invalidateRelatedQueries(qc, ['ot']);
    expect(qc.invalidateQueries).toHaveBeenCalledWith(
      expect.objectContaining({ queryKey: ['ot'] }),
    );
  });

  it('todos los grupos conocidos son invalidables sin error', async () => {
    const grupos = ['semana', 'tablero', 'tareas-hoy', 'planificacion', 'objetivos', 'bitacora', 'ot'] as const;
    const qc = makeQueryClient();
    await expect(invalidateRelatedQueries(qc, [...grupos])).resolves.toBeUndefined();
    expect(qc.invalidateQueries).toHaveBeenCalledTimes(grupos.length);
  });
});
