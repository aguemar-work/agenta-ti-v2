/**
 * src/api/__tests__/tablero.api.test.ts
 *
 * Tests para tablero.ts: función pura agruparTareasTablero + 
 * getTareasTablero con InsForge mockeado.
 */

import { describe, expect, it, vi, beforeEach } from 'vitest';
import { agruparTareasTablero } from '@/api/tablero';
import { makeTarea, FECHAS } from '@/test/helpers';

const HOY = FECHAS.HOY;

// ---------------------------------------------------------------------------
// agruparTareasTablero — función pura, sin mocks de red
// ---------------------------------------------------------------------------

describe('agruparTareasTablero', () => {

  describe('columnas correctas por estado', () => {

    it('tarea pendiente va a columna pendiente', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'pendiente' })], HOY);
      expect(cols.pendiente).toHaveLength(1);
      expect(cols.en_progreso).toHaveLength(0);
    });

    it('tarea atrasada va a columna pendiente (misma columna visual)', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'atrasada' })], HOY);
      expect(cols.pendiente).toHaveLength(1);
    });

    it('tarea en_progreso va a columna en_progreso', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'en_progreso' })], HOY);
      expect(cols.en_progreso).toHaveLength(1);
    });

    it('tarea bloqueada va a columna bloqueada', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'bloqueada' })], HOY);
      expect(cols.bloqueada).toHaveLength(1);
    });

    it('tarea completada va a columna completada', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'completada', fecha_completada: HOY })], HOY);
      expect(cols.completada).toHaveLength(1);
    });
  });

  describe('múltiples tareas', () => {

    it('distribuye correctamente N tareas en sus columnas correspondientes', () => {
      const tareas = [
        makeTarea({ id: 'id-1', estado: 'pendiente' }),
        makeTarea({ id: 'id-2', estado: 'en_progreso' }),
        makeTarea({ id: 'id-3', estado: 'bloqueada' }),
        makeTarea({ id: 'id-4', estado: 'completada', fecha_completada: HOY }),
        makeTarea({ id: 'id-5', estado: 'atrasada' }),
      ];

      const cols = agruparTareasTablero(tareas, HOY);

      expect(cols.pendiente).toHaveLength(2);
      expect(cols.en_progreso).toHaveLength(1);
      expect(cols.bloqueada).toHaveLength(1);
      expect(cols.completada).toHaveLength(1);
    });
  });

  describe('lista vacía', () => {

    it('devuelve todas las columnas vacías cuando no hay tareas', () => {
      const cols = agruparTareasTablero([], HOY);
      expect(cols.pendiente).toHaveLength(0);
      expect(cols.en_progreso).toHaveLength(0);
      expect(cols.bloqueada).toHaveLength(0);
      expect(cols.completada).toHaveLength(0);
    });
  });

  describe('estados no mapeados (reprogramada)', () => {

    it('tarea reprogramada va a columna pendiente (catch-all)', () => {
      const cols = agruparTareasTablero([makeTarea({ estado: 'reprogramada' })], HOY);
      expect(cols.pendiente).toHaveLength(1);
    });
  });
});

// ---------------------------------------------------------------------------
// getTareasTablero — con InsForge mockeado
// ---------------------------------------------------------------------------

const mockOrder = vi.fn();
const mockSelect = vi.fn();
const mockFrom = vi.fn();

vi.mock('@/lib/insforge', () => ({
  getInsforge: () => ({ database: { from: mockFrom } }),
}));

vi.mock('@/lib/schemas', async (importOriginal) => {
  const orig = await importOriginal<typeof import('@/lib/schemas')>();
  return { ...orig, parseTarea: (r: unknown) => r };
});

function setupChain(data: unknown[]) {
  mockOrder.mockResolvedValue({ data, error: null });
  mockSelect.mockReturnValue({ order: mockOrder });
  mockFrom.mockReturnValue({ select: mockSelect });
}

describe('getTareasTablero', () => {

  beforeEach(() => {
    mockFrom.mockClear();
    mockSelect.mockClear();
    mockOrder.mockClear();
  });

  it('filtra tareas canceladas del resultado', async () => {
    const { getTareasTablero } = await import('@/api/tablero');
    setupChain([
      makeTarea({ id: '1', estado: 'pendiente' }),
      makeTarea({ id: '2', estado: 'cancelada' }),
    ]);

    const result = await getTareasTablero({ usuarioId: 'todos', objetivoId: 'todos', mostrarCompletadas: false });
    expect(result.every((t) => t.estado !== 'cancelada')).toBe(true);
    expect(result).toHaveLength(1);
  });

  it('sin mostrarCompletadas, filtra también las completadas', async () => {
    const { getTareasTablero } = await import('@/api/tablero');
    setupChain([
      makeTarea({ id: '1', estado: 'pendiente' }),
      makeTarea({ id: '2', estado: 'completada', fecha_completada: HOY + 'T00:00:00Z' }),
    ]);

    const result = await getTareasTablero({ usuarioId: 'todos', objetivoId: 'todos', mostrarCompletadas: false });
    expect(result.every((t) => t.estado !== 'completada')).toBe(true);
  });

  it('lanza error si InsForge devuelve error', async () => {
    const { getTareasTablero } = await import('@/api/tablero');
    mockOrder.mockResolvedValue({ data: null, error: new Error('DB error') });
    mockSelect.mockReturnValue({ order: mockOrder });
    mockFrom.mockReturnValue({ select: mockSelect });

    await expect(
      getTareasTablero({ usuarioId: 'todos', objetivoId: 'todos', mostrarCompletadas: false }),
    ).rejects.toThrow('DB error');
  });
});
