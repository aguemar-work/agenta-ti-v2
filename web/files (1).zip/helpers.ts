/**
 * src/test/helpers.ts
 * Factories y utilidades compartidas entre todos los archivos de test.
 * Incluye fábricas para todas las entidades del dominio (Tarea, Usuario,
 * Objetivo, Evento, NotaBitacora, OrdenTrabajo).
 */

import type { Tarea, Usuario, Objetivo, Evento, NotaBitacora } from '@/types';
import type { OrdenTrabajo } from '@/api/ordenTrabajo';

// ---------------------------------------------------------------------------
// IDs fijos (deterministas entre tests)
// ---------------------------------------------------------------------------

export const TEST_IDS = {
  jefe:    'aaaaaaaa-0000-4000-a000-000000000001',
  miembro: 'bbbbbbbb-0000-4000-a000-000000000002',
  tarea1:  'cccccccc-0000-4000-a000-000000000003',
  tarea2:  'dddddddd-0000-4000-a000-000000000004',
  evento1: 'eeeeeeee-0000-4000-a000-000000000005',
  obj1:    'ffffffff-0000-4000-a000-000000000006',
  ot1:     '11111111-0000-4000-a000-000000000007',
  nota1:   '22222222-0000-4000-a000-000000000008',
} as const;

// ---------------------------------------------------------------------------
// Fechas fijas para tests deterministas
// ---------------------------------------------------------------------------

export const FECHAS = {
  HOY:    '2026-04-29',
  AYER:   '2026-04-28',
  MANANA: '2026-04-30',
  SEMANA: '202618',
} as const;

// ---------------------------------------------------------------------------
// Factory de Usuario
// ---------------------------------------------------------------------------

export function makeUsuario(overrides: Partial<Usuario> = {}): Usuario {
  return {
    id:         TEST_IDS.miembro,
    nombre:     'Kevin Miembro',
    email:      'kevin@nufago.com',
    rol:        'miembro',
    activo:     true,
    created_at: '2026-01-01T00:00:00Z',
    updated_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

export function makeJefe(overrides: Partial<Usuario> = {}): Usuario {
  return makeUsuario({
    id:     TEST_IDS.jefe,
    nombre: 'Ana Jefe',
    rol:    'jefe',
    email:  'ana@nufago.com',
    ...overrides,
  });
}

// ---------------------------------------------------------------------------
// Factory de Tarea
// ---------------------------------------------------------------------------

export function makeTarea(overrides: Partial<Tarea> = {}): Tarea {
  return {
    id:                 TEST_IDS.tarea1,
    titulo:             'Tarea de prueba',
    descripcion:        null,
    estado:             'pendiente',
    tipo:               'planificada',
    prioridad:          'media',
    fecha_planificada:  FECHAS.HOY,
    semana_planificada: FECHAS.SEMANA,
    fecha_completada:   null,
    asignado_a:         TEST_IDS.miembro,
    objetivo_id:        null,
    creado_por:         TEST_IDS.miembro,
    es_imprevisto:      false,
    nota_origen_id:     null,
    created_at:         '2026-01-01T00:00:00Z',
    updated_at:         '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Factory de Objetivo
// ---------------------------------------------------------------------------

export function makeObjetivo(overrides: Partial<Objetivo> = {}): Objetivo {
  return {
    id:             TEST_IDS.obj1,
    titulo:         'Objetivo de prueba',
    descripcion:    null,
    fecha_limite:   null,
    estado:         'activo',
    creado_por:     TEST_IDS.jefe,
    responsable_id: null,
    created_at:     '2026-01-01T00:00:00Z',
    updated_at:     '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Factory de Evento
// ---------------------------------------------------------------------------

export function makeEvento(overrides: Partial<Evento> = {}): Evento {
  return {
    id:            TEST_IDS.evento1,
    titulo:        'Reunión de prueba',
    tipo:          'reunion',
    fecha_inicio:  `${FECHAS.HOY}T09:00:00.000Z`,
    fecha_fin:     `${FECHAS.HOY}T10:00:00.000Z`,
    usuario_id:    TEST_IDS.miembro,
    es_recurrente: false,
    created_at:    '2026-01-01T00:00:00Z',
    updated_at:    '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Factory de NotaBitacora
// ---------------------------------------------------------------------------

export function makeNota(overrides: Partial<NotaBitacora> = {}): NotaBitacora {
  return {
    id:            TEST_IDS.nota1,
    contenido:     'Nota de prueba para el equipo',
    usuario_id:    TEST_IDS.miembro,
    objetivo_id:   null,
    visibilidad:   'todos',
    convertida_en: null,
    created_at:    '2026-01-01T00:00:00Z',
    updated_at:    '2026-01-01T00:00:00Z',
    ...overrides,
  } as NotaBitacora;
}

// ---------------------------------------------------------------------------
// Factory de OrdenTrabajo
// ---------------------------------------------------------------------------

export function makeOT(overrides: Partial<OrdenTrabajo> = {}): OrdenTrabajo {
  return {
    id:                   TEST_IDS.ot1,
    numero:               'OT-2026-001',
    creado_por:           TEST_IDS.miembro,
    tipo_trabajo_id:      null,
    tarea_id:             null,
    objetivo_id:          null,
    estado:               'borrador',
    prioridad:            'normal',
    descripcion:          'Descripción de la orden de trabajo de prueba',
    area_destino:         'Sistemas',
    ubicacion:            null,
    modalidad:            'presencial',
    fecha_estimada:       FECHAS.MANANA,
    hora_inicio_est:      null,
    duracion_est_min:     null,
    equipos_materiales:   null,
    observaciones:        null,
    aprobado_por:         null,
    fecha_aprobacion:     null,
    motivo_rechazo:       null,
    fecha_inicio_real:    null,
    fecha_fin_real:       null,
    observaciones_cierre: null,
    receptor_nombre:      null,
    receptor_dni:         null,
    receptor_cargo:       null,
    created_at:           '2026-01-01T00:00:00Z',
    updated_at:           '2026-01-01T00:00:00Z',
    tipo_trabajo:         null,
    creador:              { nombre: 'Kevin Miembro', email: 'kevin@nufago.com' },
    aprobador:            null,
    tarea:                null,
    objetivo:             null,
    ...overrides,
  };
}
