/**
 * src/lib/__tests__/otEstadoTransiciones.test.ts
 *
 * Tests para las transiciones de estado de Órdenes de Trabajo.
 * Documenta el flujo válido e inválido según las reglas del dominio.
 *
 * Flujo nominal:
 *   borrador → pendiente → aprobada → en_ejecucion → completada
 *
 * Excepciones:
 *   pendiente → rechazada (solo jefe)
 *   any (activo) → cancelada
 */

import { describe, expect, it } from 'vitest';
import type { EstadoOT } from '@/api/ordenTrabajo';

// ---------------------------------------------------------------------------
// Modelo de transiciones válidas (espejo de la lógica RPC en BD)
// Usado para documentar y verificar las reglas de negocio como código.
// ---------------------------------------------------------------------------

const TRANSICIONES_VALIDAS: Record<EstadoOT, EstadoOT[]> = {
  borrador:     ['pendiente', 'cancelada'],
  pendiente:    ['aprobada', 'rechazada', 'cancelada'],
  aprobada:     ['en_ejecucion', 'cancelada'],
  en_ejecucion: ['completada', 'cancelada'],
  completada:   [],
  rechazada:    [],
  cancelada:    [],
};

function puedeTransicionar(desde: EstadoOT, hacia: EstadoOT): boolean {
  return TRANSICIONES_VALIDAS[desde].includes(hacia);
}

describe('Transiciones de estado de OT', () => {

  describe('flujo nominal (happy path)', () => {

    it('borrador → pendiente (enviar OT)', () => {
      expect(puedeTransicionar('borrador', 'pendiente')).toBe(true);
    });

    it('pendiente → aprobada (jefe aprueba)', () => {
      expect(puedeTransicionar('pendiente', 'aprobada')).toBe(true);
    });

    it('aprobada → en_ejecucion (técnico inicia trabajo)', () => {
      expect(puedeTransicionar('aprobada', 'en_ejecucion')).toBe(true);
    });

    it('en_ejecucion → completada (técnico completa con receptor)', () => {
      expect(puedeTransicionar('en_ejecucion', 'completada')).toBe(true);
    });
  });

  describe('excepciones: rechazo y cancelación', () => {

    it('pendiente → rechazada (jefe rechaza)', () => {
      expect(puedeTransicionar('pendiente', 'rechazada')).toBe(true);
    });

    it('borrador → cancelada', () => {
      expect(puedeTransicionar('borrador', 'cancelada')).toBe(true);
    });

    it('aprobada → cancelada', () => {
      expect(puedeTransicionar('aprobada', 'cancelada')).toBe(true);
    });
  });

  describe('estados finales: no tienen transiciones salientes', () => {

    it('completada → cualquier estado → rechazado', () => {
      const todos: EstadoOT[] = ['borrador', 'pendiente', 'aprobada', 'en_ejecucion', 'rechazada', 'cancelada'];
      for (const hacia of todos) {
        expect(puedeTransicionar('completada', hacia)).toBe(false);
      }
    });

    it('rechazada → cualquier estado → rechazado', () => {
      const todos: EstadoOT[] = ['borrador', 'pendiente', 'aprobada', 'en_ejecucion', 'completada', 'cancelada'];
      for (const hacia of todos) {
        expect(puedeTransicionar('rechazada', hacia)).toBe(false);
      }
    });

    it('cancelada → cualquier estado → rechazado', () => {
      const todos: EstadoOT[] = ['borrador', 'pendiente', 'aprobada', 'en_ejecucion', 'completada', 'rechazada'];
      for (const hacia of todos) {
        expect(puedeTransicionar('cancelada', hacia)).toBe(false);
      }
    });
  });

  describe('transiciones inválidas no permitidas', () => {

    it('borrador NO puede ir a aprobada (saltando pendiente)', () => {
      expect(puedeTransicionar('borrador', 'aprobada')).toBe(false);
    });

    it('pendiente NO puede ir a en_ejecucion (saltando aprobada)', () => {
      expect(puedeTransicionar('pendiente', 'en_ejecucion')).toBe(false);
    });

    it('borrador NO puede ir a completada directamente', () => {
      expect(puedeTransicionar('borrador', 'completada')).toBe(false);
    });

    it('aprobada NO puede volver a pendiente', () => {
      expect(puedeTransicionar('aprobada', 'pendiente')).toBe(false);
    });
  });
});
