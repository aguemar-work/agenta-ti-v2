/**
 * src/lib/__tests__/objetivoProgreso.test.ts
 *
 * Tests para calcularPorcentajeObjetivo y nivelRiesgoObjetivo de tareaUrgencia.ts.
 * Complementan los tests existentes en tareaUrgencia.test.ts.
 */

import { describe, expect, it } from 'vitest';
import {
  calcularPorcentajeObjetivo,
  nivelRiesgoObjetivo,
  type TareaResumenProgreso,
} from '@/lib/tareaUrgencia';
import {
  UMBRAL_OBJETIVO_CRITICO,
  UMBRAL_OBJETIVO_MODERADO,
  UMBRAL_OBJETIVO_ACEPTABLE,
} from '@/lib/constants';

// ---------------------------------------------------------------------------
// calcularPorcentajeObjetivo
// ---------------------------------------------------------------------------

describe('calcularPorcentajeObjetivo', () => {

  it('devuelve 0 cuando no hay tareas', () => {
    expect(calcularPorcentajeObjetivo([])).toBe(0);
  });

  it('devuelve 0 cuando todas las tareas están canceladas', () => {
    const tareas: TareaResumenProgreso[] = [
      { estado: 'cancelada', prioridad: 'alta' },
      { estado: 'cancelada', prioridad: 'media' },
    ];
    expect(calcularPorcentajeObjetivo(tareas)).toBe(0);
  });

  it('devuelve 100 cuando todas las tareas activas están completadas', () => {
    const tareas: TareaResumenProgreso[] = [
      { estado: 'completada', prioridad: 'alta' },
      { estado: 'completada', prioridad: 'media' },
    ];
    expect(calcularPorcentajeObjetivo(tareas)).toBe(100);
  });

  it('excluye tareas canceladas del denominador (no penalizan)', () => {
    // 1 alta completada (3pts) de 1 alta total (3pts) = 100%, ignorando cancelada
    const tareas: TareaResumenProgreso[] = [
      { estado: 'completada', prioridad: 'alta' },
      { estado: 'cancelada', prioridad: 'alta' },
    ];
    expect(calcularPorcentajeObjetivo(tareas)).toBe(100);
  });

  it('calcula correctamente con pesos mixtos', () => {
    // alta=3, media=2, baja=1 → total activas = 3+2+1 = 6
    // completadas: baja (1 pt) → 1/6 * 100 = 17 (rounded)
    const tareas: TareaResumenProgreso[] = [
      { estado: 'completada', prioridad: 'baja' },
      { estado: 'pendiente',  prioridad: 'media' },
      { estado: 'pendiente',  prioridad: 'alta' },
    ];
    expect(calcularPorcentajeObjetivo(tareas)).toBe(Math.round((1 / 6) * 100));
  });

  it('calcula correctamente con tareas de alta prioridad completadas', () => {
    // alta(3) completada de alta(3)+media(2) total = 3/5 = 60%
    const tareas: TareaResumenProgreso[] = [
      { estado: 'completada', prioridad: 'alta' },
      { estado: 'pendiente',  prioridad: 'media' },
    ];
    expect(calcularPorcentajeObjetivo(tareas)).toBe(60);
  });
});

// ---------------------------------------------------------------------------
// nivelRiesgoObjetivo
// ---------------------------------------------------------------------------

describe('nivelRiesgoObjetivo', () => {

  const FECHA_LIMITE = '2026-06-30';

  it('devuelve "sin_fecha" cuando no hay fecha_limite', () => {
    expect(nivelRiesgoObjetivo(80, null)).toBe('sin_fecha');
  });

  it('devuelve "sin_fecha" cuando totalTareas es 0', () => {
    expect(nivelRiesgoObjetivo(0, FECHA_LIMITE, 0)).toBe('sin_fecha');
  });

  it(`devuelve "critico" cuando porcentaje < ${UMBRAL_OBJETIVO_CRITICO}`, () => {
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_CRITICO - 1, FECHA_LIMITE)).toBe('critico');
    expect(nivelRiesgoObjetivo(0, FECHA_LIMITE)).toBe('critico');
  });

  it(`devuelve "moderado" cuando ${UMBRAL_OBJETIVO_CRITICO} ≤ porcentaje < ${UMBRAL_OBJETIVO_MODERADO}`, () => {
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_CRITICO, FECHA_LIMITE)).toBe('moderado');
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_MODERADO - 1, FECHA_LIMITE)).toBe('moderado');
  });

  it(`devuelve "aceptable" cuando ${UMBRAL_OBJETIVO_MODERADO} ≤ porcentaje < ${UMBRAL_OBJETIVO_ACEPTABLE}`, () => {
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_MODERADO, FECHA_LIMITE)).toBe('aceptable');
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_ACEPTABLE - 1, FECHA_LIMITE)).toBe('aceptable');
  });

  it(`devuelve "en_ritmo" cuando porcentaje ≥ ${UMBRAL_OBJETIVO_ACEPTABLE}`, () => {
    expect(nivelRiesgoObjetivo(UMBRAL_OBJETIVO_ACEPTABLE, FECHA_LIMITE)).toBe('en_ritmo');
    expect(nivelRiesgoObjetivo(100, FECHA_LIMITE)).toBe('en_ritmo');
  });
});
