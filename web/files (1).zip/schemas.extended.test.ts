/**
 * src/lib/__tests__/schemas.extended.test.ts
 *
 * Tests adicionales para validación Zod: OrdenTrabajoSchema, EventoSchema,
 * NotaBitacoraSchema. Complementan el schemas.test.ts existente.
 */

import { describe, expect, it } from 'vitest';
import { OrdenTrabajoSchema, EventoSchema, NotaBitacoraSchema } from '@/lib/schemas';
import { TEST_IDS, FECHAS } from '@/test/helpers';

// ---------------------------------------------------------------------------
// OrdenTrabajoSchema
// ---------------------------------------------------------------------------

describe('OrdenTrabajoSchema', () => {

  const baseOT = {
    id:                   TEST_IDS.ot1,
    numero:               'OT-2026-001',
    creado_por:           TEST_IDS.miembro,
    tipo_trabajo_id:      null,
    tarea_id:             null,
    objetivo_id:          null,
    estado:               'borrador',
    prioridad:            'normal',
    descripcion:          'Descripción válida',
    area_destino:         'Sistemas',
    ubicacion:            null,
    modalidad:            'presencial',
    fecha_estimada:       FECHAS.MANANA,
    hora_inicio_est:      null,
    duracion_est_min:     null,
    equipos_materiales:   null,
    observaciones:        null,
    aprobado_por:         null,
    fecha_aprobacion:     null,
    motivo_rechazo:       null,
    fecha_inicio_real:    null,
    fecha_fin_real:       null,
    observaciones_cierre: null,
    receptor_nombre:      null,
    receptor_dni:         null,
    receptor_cargo:       null,
    created_at:           '2026-01-01T00:00:00Z',
    updated_at:           '2026-01-01T00:00:00Z',
  };

  it('parsea una OT válida en estado borrador', () => {
    const result = OrdenTrabajoSchema.safeParse(baseOT);
    expect(result.success).toBe(true);
  });

  it('rechaza estado inválido', () => {
    const result = OrdenTrabajoSchema.safeParse({ ...baseOT, estado: 'invalido' });
    expect(result.success).toBe(false);
  });

  it('rechaza modalidad inválida', () => {
    const result = OrdenTrabajoSchema.safeParse({ ...baseOT, modalidad: 'telepresencia' });
    expect(result.success).toBe(false);
  });

  it('acepta todos los estados válidos de OT', () => {
    const estados = ['borrador', 'pendiente', 'aprobada', 'en_ejecucion', 'completada', 'rechazada', 'cancelada'] as const;
    for (const estado of estados) {
      const result = OrdenTrabajoSchema.safeParse({ ...baseOT, estado });
      expect(result.success, `estado "${estado}" debería ser válido`).toBe(true);
    }
  });

  it('acepta todas las modalidades válidas', () => {
    const modalidades = ['presencial', 'remoto', 'viaje'] as const;
    for (const modalidad of modalidades) {
      const result = OrdenTrabajoSchema.safeParse({ ...baseOT, modalidad });
      expect(result.success, `modalidad "${modalidad}" debería ser válida`).toBe(true);
    }
  });

  it('acepta prioridades normal y urgente', () => {
    expect(OrdenTrabajoSchema.safeParse({ ...baseOT, prioridad: 'normal' }).success).toBe(true);
    expect(OrdenTrabajoSchema.safeParse({ ...baseOT, prioridad: 'urgente' }).success).toBe(true);
    expect(OrdenTrabajoSchema.safeParse({ ...baseOT, prioridad: 'baja' }).success).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// EventoSchema
// ---------------------------------------------------------------------------

describe('EventoSchema', () => {

  const baseEvento = {
    id:            TEST_IDS.evento1,
    titulo:        'Reunión de planificación',
    tipo:          'reunion',
    fecha_inicio:  `${FECHAS.HOY}T09:00:00.000Z`,
    fecha_fin:     `${FECHAS.HOY}T10:00:00.000Z`,
    usuario_id:    TEST_IDS.miembro,
    es_recurrente: false,
    created_at:    '2026-01-01T00:00:00Z',
    updated_at:    '2026-01-01T00:00:00Z',
  };

  it('parsea un evento válido', () => {
    const result = EventoSchema.safeParse(baseEvento);
    expect(result.success).toBe(true);
  });

  it('rechaza tipo de evento inválido', () => {
    const result = EventoSchema.safeParse({ ...baseEvento, tipo: 'festivo' });
    expect(result.success).toBe(false);
  });

  it('acepta todos los tipos de evento válidos', () => {
    const tipos = ['reunion', 'entrega', 'personal', 'otro'] as const;
    for (const tipo of tipos) {
      const result = EventoSchema.safeParse({ ...baseEvento, tipo });
      expect(result.success, `tipo "${tipo}" debería ser válido`).toBe(true);
    }
  });

  it('acepta recurrencia_id opcional como UUID o null', () => {
    const conRecurrencia = { ...baseEvento, recurrencia_id: TEST_IDS.obj1 };
    expect(EventoSchema.safeParse(conRecurrencia).success).toBe(true);

    const sinRecurrencia = { ...baseEvento, recurrencia_id: null };
    expect(EventoSchema.safeParse(sinRecurrencia).success).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// NotaBitacoraSchema
// ---------------------------------------------------------------------------

describe('NotaBitacoraSchema', () => {

  const baseNota = {
    id:            TEST_IDS.nota1,
    contenido:     'Nota de prueba del equipo de TI',
    usuario_id:    TEST_IDS.miembro,
    objetivo_id:   null,
    visibilidad:   'todos',
    convertida_en: null,
    created_at:    '2026-01-01T00:00:00Z',
    updated_at:    '2026-01-01T00:00:00Z',
  };

  it('parsea una nota con visibilidad "todos"', () => {
    expect(NotaBitacoraSchema.safeParse(baseNota).success).toBe(true);
  });

  it('parsea una nota privada con convertida_en "tarea"', () => {
    const result = NotaBitacoraSchema.safeParse({
      ...baseNota,
      visibilidad:   'privado',
      convertida_en: 'tarea',
    });
    expect(result.success).toBe(true);
  });

  it('rechaza visibilidad inválida', () => {
    const result = NotaBitacoraSchema.safeParse({ ...baseNota, visibilidad: 'publico' });
    expect(result.success).toBe(false);
  });

  it('rechaza convertida_en con valor inválido', () => {
    const result = NotaBitacoraSchema.safeParse({ ...baseNota, convertida_en: 'objetivo' });
    expect(result.success).toBe(false);
  });

  it('acepta todas las visibilidades válidas', () => {
    const visibilidades = ['todos', 'solo_jefe', 'privado'] as const;
    for (const visibilidad of visibilidades) {
      const result = NotaBitacoraSchema.safeParse({ ...baseNota, visibilidad });
      expect(result.success, `visibilidad "${visibilidad}" debería ser válida`).toBe(true);
    }
  });

  it('acepta convertida_en nulo, tarea o evento', () => {
    for (const val of [null, 'tarea', 'evento'] as const) {
      const result = NotaBitacoraSchema.safeParse({ ...baseNota, convertida_en: val });
      expect(result.success, `convertida_en "${String(val)}" debería ser válido`).toBe(true);
    }
  });
});
