/**
 * src/hooks/__tests__/useDraftForm.test.ts
 *
 * Tests para las funciones auxiliares de useDraftForm:
 * - lógica de lectura/escritura/borrado de localStorage (isoladas)
 * - lógica isEqual (hasChanges)
 *
 * Nota de entorno: Los tests de renderHook para este hook requieren DOM con
 * localStorage disponible. En este sandbox, los workers con DOM salen por OOM.
 * Los tests de integración del hook completo se ejecutan localmente con
 * `vitest run --config Vitest.config.ts` (jsdom habilitado).
 *
 * Esta suite cubre la lógica de dominio pura del hook sin renderizado.
 */

import { describe, expect, it, beforeEach, vi } from 'vitest';

// ---------------------------------------------------------------------------
// Implementación inline de las funciones auxiliares del hook
// (extraídas de hooks/useDraftForm.ts para testear en aislamiento)
// ---------------------------------------------------------------------------

const DRAFT_PREFIX = 'mc_draft_';

const mockStore: Record<string, string> = {};

const mockLocalStorage = {
  getItem:    (key: string) => mockStore[key] ?? null,
  setItem:    (key: string, value: string) => { mockStore[key] = value; },
  removeItem: (key: string) => { delete mockStore[key]; },
  clear:      () => { Object.keys(mockStore).forEach((k) => delete mockStore[k]); },
};

function readDraft<T>(key: string): T | null {
  try {
    const raw = mockLocalStorage.getItem(DRAFT_PREFIX + key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeDraft<T>(key: string, value: T) {
  mockLocalStorage.setItem(DRAFT_PREFIX + key, JSON.stringify(value));
}

function deleteDraft(key: string) {
  mockLocalStorage.removeItem(DRAFT_PREFIX + key);
}

function isEqual(a: unknown, b: unknown): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}

// ---------------------------------------------------------------------------

beforeEach(() => {
  mockLocalStorage.clear();
});

// ---------------------------------------------------------------------------
// readDraft
// ---------------------------------------------------------------------------

describe('readDraft', () => {

  it('devuelve null cuando no hay borrador guardado', () => {
    expect(readDraft('key-sin-borrador')).toBeNull();
  });

  it('recupera el objeto guardado previamente', () => {
    const data = { titulo: 'Tarea guardada', prioridad: 'alta' };
    writeDraft('mi-form', data);
    expect(readDraft('mi-form')).toEqual(data);
  });

  it('devuelve null si el JSON guardado está corrupto', () => {
    mockLocalStorage.setItem(DRAFT_PREFIX + 'corrupto', '{no-es-json');
    expect(readDraft('corrupto')).toBeNull();
  });

  it('las claves son prefijadas (mc_draft_) para no colisionar con otras keys', () => {
    writeDraft('form-A', { x: 1 });
    // La key directa sin prefijo no debe existir
    expect(mockLocalStorage.getItem('form-A')).toBeNull();
    // Pero con prefijo sí
    expect(mockLocalStorage.getItem(DRAFT_PREFIX + 'form-A')).not.toBeNull();
  });
});

// ---------------------------------------------------------------------------
// writeDraft
// ---------------------------------------------------------------------------

describe('writeDraft', () => {

  it('serializa el objeto como JSON en localStorage', () => {
    const data = { descripcion: 'Prueba', activo: true };
    writeDraft('write-test', data);
    const raw = mockLocalStorage.getItem(DRAFT_PREFIX + 'write-test');
    expect(JSON.parse(raw!)).toEqual(data);
  });

  it('sobreescribe un borrador existente con el nuevo valor', () => {
    writeDraft('overwrite', { v: 1 });
    writeDraft('overwrite', { v: 2 });
    expect(readDraft<{ v: number }>('overwrite')?.v).toBe(2);
  });

  it('persiste arrays correctamente', () => {
    writeDraft('arr', [1, 2, 3]);
    expect(readDraft('arr')).toEqual([1, 2, 3]);
  });
});

// ---------------------------------------------------------------------------
// deleteDraft
// ---------------------------------------------------------------------------

describe('deleteDraft', () => {

  it('elimina el borrador de localStorage', () => {
    writeDraft('to-delete', { a: 1 });
    deleteDraft('to-delete');
    expect(readDraft('to-delete')).toBeNull();
  });

  it('no lanza error al eliminar una key inexistente', () => {
    expect(() => deleteDraft('no-existe')).not.toThrow();
  });
});

// ---------------------------------------------------------------------------
// isEqual — detección de cambios (hasChanges)
// ---------------------------------------------------------------------------

describe('isEqual', () => {

  it('devuelve true para objetos idénticos', () => {
    expect(isEqual({ a: 1, b: 'x' }, { a: 1, b: 'x' })).toBe(true);
  });

  it('devuelve false para objetos con valores distintos', () => {
    expect(isEqual({ a: 1 }, { a: 2 })).toBe(false);
  });

  it('devuelve false para objetos con claves distintas', () => {
    expect(isEqual({ a: 1 }, { b: 1 })).toBe(false);
  });

  it('devuelve true para strings iguales', () => {
    expect(isEqual('hola', 'hola')).toBe(true);
  });

  it('devuelve false para strings distintos', () => {
    expect(isEqual('hola', 'mundo')).toBe(false);
  });

  it('devuelve true para arrays iguales', () => {
    expect(isEqual([1, 2, 3], [1, 2, 3])).toBe(true);
  });

  it('devuelve false para arrays distintos', () => {
    expect(isEqual([1, 2], [1, 3])).toBe(false);
  });

  it('devuelve true para null === null', () => {
    expect(isEqual(null, null)).toBe(true);
  });

  it('devuelve false para null vs objeto vacío', () => {
    expect(isEqual(null, {})).toBe(false);
  });

  it('detecta cambio en campo anidado', () => {
    const a = { form: { titulo: 'A', items: [1, 2] } };
    const b = { form: { titulo: 'A', items: [1, 3] } };
    expect(isEqual(a, b)).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Round-trip: write → read → verify (test de integración de utilidades)
// ---------------------------------------------------------------------------

describe('ciclo completo write→read→delete', () => {

  it('escribe, lee, y borra un borrador correctamente', () => {
    const key = 'ciclo-completo';
    const data = { titulo: 'Revisión de servidores', prioridad: 'alta', items: [1, 2] };

    writeDraft(key, data);
    expect(readDraft(key)).toEqual(data);

    deleteDraft(key);
    expect(readDraft(key)).toBeNull();
  });

  it('múltiples borradores con distintas keys coexisten sin interferencia', () => {
    writeDraft('form-1', { a: 1 });
    writeDraft('form-2', { a: 2 });

    expect(readDraft<{ a: number }>('form-1')?.a).toBe(1);
    expect(readDraft<{ a: number }>('form-2')?.a).toBe(2);

    deleteDraft('form-1');
    expect(readDraft('form-1')).toBeNull();
    expect(readDraft<{ a: number }>('form-2')?.a).toBe(2);
  });
});
